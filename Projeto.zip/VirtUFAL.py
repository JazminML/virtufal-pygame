# time.sleep(3)
import pygame, sys, os, time, random
from pygame.locals import *
#import exemplo_3_pronto
pygame.init()
clock = pygame.time.Clock()
pygame.mixer.init()
icone_arquivo = os.path.join("Imagens", "Icone.png")
icone = pygame.image.load(icone_arquivo)
pygame.display.set_icon(icone)
pygame.display.set_caption("VirtUFAL")
tela = pygame.display.set_mode((800,600))

tela = pygame.display.get_surface()
fundo = pygame.Surface(tela.get_size())
fundo = fundo.convert()
fundo.fill((255, 255, 255))


musica_arquivo = [(os.path.join("Sons", "Menu_musica.ogg")),
                  (os.path.join("Sons", "Menu_botao.wav"))]
musica1 = [(pygame.mixer.Sound(musica_arquivo[0])),
           (pygame.mixer.Sound(musica_arquivo[1]))]
imagem_arquivo = [(os.path.join("Imagens", "Menu", "Menu.png")),
                  (os.path.join("Imagens", "Menu", "1.png")),
                  (os.path.join("Imagens", "Menu", "2.png")),
                  (os.path.join("Imagens", "Menu", "3.png")),
                  (os.path.join("Imagens", "Menu", "4.png")),
                  (os.path.join("Imagens", "Menu", "5.png")),
                  (os.path.join("Imagens", "Menu", "6.png"))]
imagem1 = [(pygame.image.load(imagem_arquivo[0])),
           (pygame.image.load(imagem_arquivo[1])),
           (pygame.image.load(imagem_arquivo[2])),
           (pygame.image.load(imagem_arquivo[3])),
           (pygame.image.load(imagem_arquivo[4])),
           (pygame.image.load(imagem_arquivo[5])),
           (pygame.image.load(imagem_arquivo[6]))]


class menu:
    def __init__(self):
        self.imagem = imagem1[0]
        self.menu_tela = imagem1[1]
        self.musica = musica1[0]
        self.botao = musica1[1]
        self.musica.play(-1)
        self.pos = 1
        self.pos_lado = 1
        self.fechar = False
        self.iniciar = False
    def funcionalidade(self):
        pygame.event.pump()
        key = pygame.key.get_pressed()
        if key[pygame.K_s] or key[pygame.K_DOWN] and self.pos_lado == 1:
            if self.pos == 1:
                self.menu_tela = imagem1[2]
                self.pos += 1
                self.botao.play()
            elif self.pos == 2:
                self.menu_tela = imagem1[3]
                self.pos += 1
                self.botao.play()
            elif self.pos == 3:
                self.menu_tela = imagem1[4]
                self.pos += 1
                self.botao.play()
            else:
                self.menu_tela = imagem1[1]
                self.pos -= 3
                self.botao.play()
        if key[pygame.K_w] or key[pygame.K_UP] and self.pos_lado == 1:
            if self.pos == 1:
                self.menu_tela = imagem1[4]
                self.pos += 3
                self.botao.play()
            elif self.pos == 2:
                self.menu_tela = imagem1[1]
                self.pos -= 1
                self.botao.play()
            elif self.pos == 3:
                self.menu_tela = imagem1[2]
                self.pos -= 1
                self.botao.play()
            else:
                self.menu_tela = imagem1[3]
                self.pos -= 1
                self.botao.play()
        #if key[pygame.K_RETURN] and self.pos == 1:
            #exemplo_3_pronto.main()
            
        if key[pygame.K_RETURN] and self.pos == 4:
            self.fechar = True
            self.botao.stop()
        elif key[pygame.K_RETURN] and self.pos == 3:
            self.menu_tela = imagem1[5]
            self.pos_lado += 1
        if key[pygame.K_d] or key[pygame.K_RIGHT]:
            if self.pos_lado == 2:
                self.menu_tela = imagem1[6]
                self.pos_lado += 1
                self.botao.play()
        if key[pygame.K_a] or key[pygame.K_LEFT]:
            if self.pos_lado == 3:
                self.menu_tela = imagem1[5]
                self.pos_lado -= 1
                self.botao.play()
            elif self.pos_lado == 2:
                self.menu_tela = imagem1[3]
                self.pos_lado = 1
                self.botao.play()
        
    def blit(self):
        tela.blit(self.imagem, (0,0))
        tela.blit(self.menu_tela, (0,0))
menu = menu()
        

executar = True
def loop():
    global executar
    for event in pygame.event.get():
        if (event.type == QUIT) or (menu.fechar is True):
            pygame.mixer.stop()
            executar = False
        elif event.type ==  KEYDOWN:
            menu.funcionalidade()
            pygame.key.set_repeat(0)
pygame.key.set_repeat(1)
while executar:
    clock.tick(60)
    print("FPS: %0.2f" % clock.get_fps())
    loop()

    tela.blit(fundo, (0,0))
    menu.blit()
        
    pygame.display.flip()
pygame.display.quit()
